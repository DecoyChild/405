// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>



int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// Added a variable for the expected input size 
	const int input_size = 20;

	const std::string account_number = "CharlieBrown42";
	char user_input[input_size];
	std::cout << "Enter a value: ";

	// using setw to set the maximun allowed for cin to 20
	std::cin >> std::setw(input_size) >> user_input;
	
	// Tell the user if the next value in the buffer is not a newline
	// too many characters were entered
	if (std::cin.peek() != '\n') {
		std::cout << "-* Overflow detected *- Too much data entered" << std::endl;
		
		// Clearing the rest of the input buffer
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	}

	std::cout << "You entered: " << user_input << std::endl;
	std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu