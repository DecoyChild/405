// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept> 


// Custom exception handler 
class DoMoreCustomException : public std::exception {

// private variable only accessable from inside  the class
private:
    std::string message;

public:
    // default constructor that will throw a generic message
    DoMoreCustomException() : message("There was a custom error that occured.") {}

    // constructor that will take a custom message as a string argument  
    DoMoreCustomException(const std::string& message) : message(message) {}

    const char* what() const noexcept override {
        return message.c_str();
    }

};

bool do_even_more_custom_application_logic()
{
    
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throwing a generic runtime error 
    throw std::runtime_error("Even More Custom Application Logic Failed");

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;
    
    // catching errors, printing the message to the console
    // the method will continue to the next throw
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch(const std::runtime_error& e){
        std::cout << "Error: " << e.what() << std::endl;
    }

    // throwing a custom exception using the default constructor.
    throw DoMoreCustomException();

    // this line will never get hit after the throw
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // Checking to see of the denomerator is zero before dividing.
    if (den == 0) {
        throw std::runtime_error("Cannot divide by zero.");
    }

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    // Adding a try catch for the divide by zero error
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }

}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // wrapping the uncuaght exceptions 
    try {

        // Try catch block for custom application logic 
        try {
            do_custom_application_logic();
        }
        catch (const DoMoreCustomException& e) {
            std::cout << "Error: " << e.what() << std::endl;
        }

        // std::exception handled inside function
        do_division();
    }
    // handle the exceptions that are thrown using std::exception 
    catch (const std::exception& e) {
        std::cout << "Uncaught Exception: " << e.what() << std::endl;
    }

    // Fail safe to handle exceptions where the type is not known
    catch (...) {
        std::cout << "Unknown exception occurred." << std::endl;
    }

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu