// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// Test if we can add to an empty vector
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());
    
    // add an element
    add_entries(1);

    // If adding 1 element, the collection size should be 1
    EXPECT_EQ(collection->size(), 1);
    
}

// Test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());
    
    // add 5 elements
    add_entries(5);

    // If adding 5 elements, the collection size should be 5
    EXPECT_EQ(collection->size(), 5);
}

// Test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxVectorSizeGreaterThanOrEqualToSize)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());

    // testing if the initial size is 0
    EXPECT_GE(collection->max_size(), collection->size());

    // adding 1 element
    add_entries(1);
    EXPECT_GE(collection->max_size(), collection->size());

    // clear collection and adding 5 elements
    collection->clear();
    add_entries(5);
    EXPECT_GE(collection->max_size(), collection->size());

    // clear collection and adding 10 elements
    collection->clear();
    add_entries(10);
    EXPECT_GE(collection->max_size(), collection->size());
    
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, VectorCapacityGreaterThanOrEqualToSize)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());

    // testing if the capcity is the same or greater than as the 
    EXPECT_GE(collection->capacity(), collection->size());

    // adding 1 element
    add_entries(1);
    
    // After adding elements, capacity should be greater than or equal to size
    EXPECT_GE(collection->capacity(), collection->size());

    // clear collection and adding 5 elements
    collection->clear();

    // adding 5 elements
    add_entries(5);

    // After adding elements, capacity should be greater than or equal to size
    EXPECT_GE(collection->capacity(), collection->size());

    // clear collection and adding 10 elements
    collection->clear();
    
    // adding 10 elements
    add_entries(10);

    // After adding elements, capacity should be greater than or equal to size
    EXPECT_GE(collection->capacity(), collection->size());

}

// Test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesVector)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());

    // Increasing the collection size by one
    collection->resize(collection->size() + 1);

    // Making sure the collection has increased by one
    EXPECT_EQ(collection->size(), 1);
}

// Test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesVector)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());
    
    // Increase by 5 elements
    add_entries(5);

    // Verify collection is at 5
    ASSERT_EQ(collection->size(), 5);

    // resizing the collection by -1
    collection->resize(collection->size() - 1);

    // Expecting the collection to have 4 elements 
    EXPECT_EQ(collection->size(),4);
}


// Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeDecreasesVectorToZero)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());

    // Increase by 1 element
    add_entries(1);

    // Verify collection is 1
    ASSERT_EQ(collection->size(), 1);

    // Reduce the collection by 1
    collection->resize(collection->size() - 1);

    // Expecting the collection to be empty
    EXPECT_TRUE(collection->empty());
}

// Test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());

    // Adding 5 elements 
    add_entries(5);

    // Verify collection is not empty
    ASSERT_FALSE(collection->empty());

    // Clearing the vector
    collection->clear();

    // Expects an empty vector
    EXPECT_TRUE(collection->empty());
}

// Test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseRangeErasesCollection)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());

    // Adding some elements
    add_entries(5);

    // Verify collection is not empty - we dont care how many elements we have 
    ASSERT_FALSE(collection->empty());

    // Erasing vector from a range beginning to end
    collection->erase(collection->begin(), collection->end());

    // Expecting an empty collection
    EXPECT_TRUE(collection->empty());
}

// Test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesOnlyCapacity)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());

    // Adding reserve of 5 elements 
    collection->reserve(5);

    // Expecting the vector to be size 0
    EXPECT_EQ(collection->size(), 0);

    // Expecting the capacity to be 5
    EXPECT_EQ(collection->capacity(),5);
}

// Test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, GetThrowForOutOfRangeIndex)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());

    // Adding 5 elements 
    add_entries(5);

    // Expect the out of range to throw an exception
    ASSERT_THROW(collection->at(5), std::out_of_range);

}

// Positive Test
// Test that erasing a a specific element in the collection resizes the collection and shifts remaining elements 
TEST_F(CollectionTest, RemoveSpecificElementFromVector)
{
    // Verify we are starting with an empty collection
    ASSERT_TRUE(collection->empty());

    // Adding 5 elements 
    collection->push_back(10);
    collection->push_back(20);
    collection->push_back(30);
    collection->push_back(40); // Expect this to be erased
    collection->push_back(50);

    // Verify there are 5 elements 
    ASSERT_EQ(collection->size(), 5);
    
    // Erasing the element in the 3rd index
    collection->erase(collection->begin() + 3);

    // Expecting the size to be reduced by 1
    ASSERT_EQ(collection->size(), 4);

    // Expect the next element to drop into the 3rd index
    EXPECT_EQ(collection->at(3), 50);
}

// Test trying to insert elements beyond the max size
TEST_F(CollectionTest, InsertThrowsLengthErrorWhenMoreThanMaxSize)
{
    // Adding 10 entries
    add_entries(10);

    // Expect to throw and exception when adding an element beyond its capacity
    ASSERT_THROW(collection->insert(collection->begin(), collection->max_size(), 50), std::length_error);
}
